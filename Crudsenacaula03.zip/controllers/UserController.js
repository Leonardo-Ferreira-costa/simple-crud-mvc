class UserController{ //Iniciando a class do construtor e carregando os elementos a ser utilizados.

    constructor(formId, tableId){
    this.formEl = document.getElementById(formId);
    this.tableEl = document.getElementById(tableId);



    this.onSubmit();
    this.onEdit(); //2- Chama a funcao que cria o evento listener no botao cancel do edit.

    }

    //2- Cria o evento do cancel do edit e outras funcoes do edit.
    onEdit(){

        document.querySelector("#div-update-user .btn-cancel").addEventListener("click", e =>{

            this.showPanelCreate();

        });

    }
     //2- Fim do Cria o evento do cancel do edit.


    //Evento Listener que vai acionar os metodos ao ser pressionado o botão do form.
    onSubmit(){

    this.formEl.addEventListener("submit", event => {

        event.preventDefault(); 

        this.addLine(this.getValues());
        
        });
    }

    //Obtem os dados do form e monta um JSON.
    getValues(){

        let user = {};

        [...this.formEl.elements].forEach(function(formCamp, index){
		
            user[formCamp.name] = formCamp.value;
            
           
        });
        console.log(user.nome);
    
        return new User(
            user.nome,
            user.email,
            user.celular
            
        );
        
    }

    //Adiciona uma nova linha na tabela com o novo usuario
    //2- Alterado o modo de insercao do tr, incluido o appendchild
    addLine(dataUser){
        
        let tr = document.createElement('tr');

        tr.dataset.user = JSON.stringify(dataUser);
                
        tr.innerHTML = '<td>1 </td><td>'+dataUser.nome+'</td><td>'+dataUser.celular+'</td><td>'+dataUser.email+'</td><td><div class="row"><div class="col-sm-6"><button type="button" class="btn btn-block btn-warning btn-sm btn-edit">EDITAR</button></div><div class="col-sm-6"><button type="button" class="btn btn-block btn-danger btn-sm">EXCLUIR</button></div></div></td>';

        //2- Botao editar
        tr.querySelector(".btn-edit").addEventListener("click", e =>{

            let json = JSON.parse(tr.dataset.user);
            let form = document.querySelector("#form-user-update");

                     

            for(let name in json){
                
                let field = form.querySelector("[name=" + name.replace(" ", "") + "]");

                if (field){

                        field.value = json[name];
                }
            }

            this.showPanelUpdate();
           
        });
        //2- FIm do Botao editar

        this.tableEl.appendChild(tr);

    }

    //2- Mostra e esconde os forms de criacao e edicao.
    showPanelCreate(){

        document.querySelector("#div-create-user").style.display = "block";
        document.querySelector("#div-update-user").style.display = "none";
    }

    showPanelUpdate(){

        document.querySelector("#div-create-user").style.display = "none";
        document.querySelector("#div-update-user").style.display = "block";
    }
    //2- Fim - Mostra e esconde os forms de criacao e edicao.
    
    
}