let userController = new UserController("form-user-create", "table-users");

//Editar

//1 - Duplicar o nosso formulario.

//2 - Dar funcionalidades ao botao editar e cancelar.
	//Nao esquecer nas edicoes no template com relacao aos nomes de ids e classes criados e tbm no tr do addLine.




