class User{
	
	constructor(nome, celular, email){
		
		this.nome = nome;
		this.celular = celular;
		this.email = email;
		
		
	}
	
}