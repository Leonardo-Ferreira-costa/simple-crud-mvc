class UserController{ //Iniciando a class do construtor e carregando os elementos a ser utilizados.

    //3- Acionado a nova passagemd de valores para o formUpdateId e alterado o formId para formCreateId
    constructor(formCreateId, formUpdateId, tableId){

    this.formEl = document.getElementById(formCreateId);
    this.formUpdateEl = document.getElementById(formUpdateId);
    this.tableEl = document.getElementById(tableId);



    this.onSubmit();
    this.onEdit(); //2- Chama a funcao que cria o evento listener no botao cancel do edit.

    }

    //2- Cria o evento do cancel do edit e outras funcoes do edit.
    onEdit(){

        document.querySelector("#div-update-user .btn-cancel").addEventListener("click", e =>{

            this.showPanelCreate();

        });

        //3- Evento do botão submit do formulario de edição.
        this.formUpdateEl.addEventListener("submit", event =>{

            event.preventDefault();
            
            let values = this.getValues(this.formUpdateEl);

            let index = this.formUpdateEl.dataset.trIndex;

            let tr = this.tableEl.rows[index];

            tr.datasetuser = JSON.stringify(values);

            tr.innerHTML = '<td>1 </td><td>'+values.nome+'</td><td>'+values.celular+'</td><td>'+values.email+'</td><td><div class="row"><div class="col-sm-6"><button type="button" class="btn btn-block btn-warning btn-sm btn-edit">EDITAR</button></div><div class="col-sm-6"><button type="button" class="btn btn-block btn-danger btn-sm">EXCLUIR</button></div></div></td>';

            this.addEventsTr(tr);

            
            console.log(values);

        });
         //3- Fim do evento do botão submit do formulario de edição.



    }
     //2- Fim do Cria o evento do cancel do edit.


    //Evento Listener que vai acionar os metodos ao ser pressionado o botão do form.
    onSubmit(){

    this.formEl.addEventListener("submit", event => {

        event.preventDefault(); 

        this.addLine(this.getValues(this.formEl));//3- Adicionado o this.formEl para a passagem de valores
        
        });
    }

    //Obtem os dados do form e monta um JSON.
    getValues(formEl){ //3- Alterado de propriedade para variavel

        let user = {};

        [...formEl.elements].forEach(function(formCamp, index){//3- retirado o this por causa da passagem de variavel
		
            user[formCamp.name] = formCamp.value;
            
           
        });
        console.log(user.nome);
    
        return new User(
            user.nome,
            user.email,
            user.celular
            
        );
        
    }

    //Adiciona uma nova linha na tabela com o novo usuario
    //2- Alterado o modo de insercao do tr, incluido o appendchild
    addLine(dataUser){
        
        let tr = document.createElement('tr');

        tr.dataset.user = JSON.stringify(dataUser);
                
        //3- Adicionado .btn-delete
        tr.innerHTML = '<td>1 </td><td>'+dataUser.nome+'</td><td>'+dataUser.celular+'</td><td>'+dataUser.email+'</td><td><div class="row"><div class="col-sm-6"><button type="button" class="btn btn-block btn-warning btn-sm btn-edit">EDITAR</button></div><div class="col-sm-6"><button type="button" class="btn btn-block btn-danger btn-sm btn-delete">EXCLUIR</button></div></div></td>';


        //3- Alterado devido ao uso em mais de um lugar, virou um metodo.
        this.addEventsTr(tr);
        //3- FIm do Botao editar

        this.tableEl.appendChild(tr);

    }

    //3- Metodo criado devido a uso em mais de um local.
    addEventsTr(tr){

        tr.querySelector(".btn-delete").addEventListener("click", e =>{

            if(confirm("A exclusão será permanente, tem certeza?")){

                tr.remove();


            }

        });

        tr.querySelector(".btn-edit").addEventListener("click", e =>{

            let json = JSON.parse(tr.dataset.user);
            let form = document.querySelector("#form-user-update");

            form.dataset.trIndex = tr.sectionRowIndex;         


            for(let name in json){
                
                let field = form.querySelector("[name=" + name.replace(" ", "") + "]");

                if (field){

                        field.value = json[name];
                }
            }

            this.showPanelUpdate();
           
        });


    }
    //3- Fim do Metodo criado devido a uso em mais de um local.


    //2- Mostra e esconde os forms de criacao e edicao.
    showPanelCreate(){

        document.querySelector("#div-create-user").style.display = "block";
        document.querySelector("#div-update-user").style.display = "none";
    }

    showPanelUpdate(){

        document.querySelector("#div-create-user").style.display = "none";
        document.querySelector("#div-update-user").style.display = "block";
    }
    //2- Fim - Mostra e esconde os forms de criacao e edicao.
    
    
}